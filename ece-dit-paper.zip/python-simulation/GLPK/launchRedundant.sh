#!/bin/bash

glpsol -m ./GLPK/redundant.mod -d ./redundant_temp.dat
