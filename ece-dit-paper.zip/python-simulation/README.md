Simulation
==========

A simulation of the DBF feasibility test for generated tasks sytem. Various upper limits are used.

Task
----
Task and TaskSystem class

TaskGenerator
-------------
Provides methods to generate Task system

algorithms
----------
Contains implementation real-time specific algorithms s.t. computation of the first DIT

myAlgebra
---------
Contains implementation of algebra algorithms s.t. primal factorization, egcd, etc

main
----
Launch our tests and print result (synchr case)

mainAsynchr
-----------
Launch our asynchr test
